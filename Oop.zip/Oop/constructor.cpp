// 1. Default Constructor (No Parameters)

// #include <iostream>
// using namespace std;

// class Car {
// public:
//     string brand;

//     // Default Constructor
//     Car() {  
//         brand = "Tesla";
//         cout << "Default Constructor Called" << endl;
//     }

//     void display() {
//         cout << "Car Brand: " << brand << endl;
//     }
// };

// int main() {
//     Car myCar;  // Default Constructor is automatically called
//     myCar.display();
//     return 0;
// }


// 2. Parameterized Constructor

// #include <iostream>
// using namespace std;

// class Car {
// public:
//     string brand;

//     // Parameterized Constructor
//     // Car(string b) {  
//     //     brand = b;
//     // }

//     void display() {
//         cout << "Car Brand: " << brand << endl;
//     }
// };

// int main() {
//     Car car1("BMW");
//     car1.display();

//     Car car2("Audi");
//     car2.display();

//     return 0;
// }


// 3. Copy Constructor
#include <iostream>
using namespace std;

class Car {
public:
    string brand;

    // Parameterized Constructor
    Car(string b ) {  
        brand = b;

    }

    // Copy Constructor
    Car( Car &c) {  
        brand = c.brand;
      
        cout << "Copy Constructor Called" << endl;
    }

    void display() {
        cout << "Car Brand: " << brand << endl;
    }
};

int main() {
    Car car1("Ford" );
    //Car car2 = car1;  // Copy Constructor is called
    Car car2(car1);

    car1.display();
    car2.display();

    return 0;
}



