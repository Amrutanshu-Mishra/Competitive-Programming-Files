// #include <iostream>
// using namespace std;

// class Math {
// public:
//     // Function Overloading: Same function name, different parameters
//     int add(int a, int b) {
//         return a + b;
//     }
    
//     double add(double a, double b) {
//         return a + b;
//     }

//     int add(int a, int b, int c) {
//         return a + b + c;
//     }
// };

// int main() {
//     Math obj;
//     cout << obj.add(5, 10) << endl;        // Calls add(int, int)
//     cout << obj.add(5.5, 10.2) << endl;    // Calls add(double, double)
//     cout << obj.add(5, 10, 15) << endl;    // Calls add(int, int, int)
//     return 0;
// }


#include <iostream>
using namespace std;

class loc {
    int longitude, latitude;
    
public:
    loc() {}  // constructor to construct temporary objects
    loc(int lg, int lt):longitude(lg),latitude(lt) {
          // parameterized constructor
    }
    
    void show() {
        cout << longitude << " ";
        cout << latitude << "\n";
    }

    // Operator overloading for addition
    loc operator+(loc op2) { 
        loc temp;
        temp.longitude = longitude + op2.longitude;
        temp.latitude = latitude + op2.latitude;
        return temp;
    }

    // Operator overloading for subtraction
    loc operator-(loc op2) {
        loc temp;
        temp.longitude = longitude - op2.longitude;
        temp.latitude = latitude - op2.latitude;
        return temp;
    }

    // Pre-increment operator overloading
    loc operator++() {
        ++longitude;
        ++latitude;
        return *this;
    }

    // Post-increment operator overloading
    loc operator++(int) {
        longitude++;
        latitude++;
        return *this;
    }
};

int main() {
    loc ob1(101, 202), ob2(50, 60), ob3(95, 85);
    
    ++ob2;            // Pre-increment ob2
    ob2.show();       // Display the updated values of ob2
    
    ob3 = ob3 - ob2;  // Subtract ob2 from ob3
    
    ob3.show();       // Display the updated values of ob3
    return 0;
}