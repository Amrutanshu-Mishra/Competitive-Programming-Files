// #include <iostream>
// using namespace std;

// // Base class (Parent)
// class Animal {
// public:
//     void eat() {
//         cout << "This animal eats food." << endl;
//     }
// };

// // Derived class (Child) inheriting from Animal
// class Dog : public Animal {
// public:
//     void bark() {
//         cout << "The dog barks." << endl;
//     }
// };

// int main() {
//     Dog myDog;

//     myDog.eat();   // Inherited from Animal
//     myDog.bark();  // Defined in Dog

//     return 0;
// }



#include <iostream>
using namespace std;

// Parent 1
class Engine {
public:
    void start() {
        cout << "Engine started!" << endl;
    }
};

// Parent 2
class Wheels {
public:
    void rotate() {
        cout << "Wheels rotating!" << endl;
    }
};

// Child class inheriting from Engine and Wheels
class Car : public Engine, public Wheels {
public:
    void drive() {
        cout << "Car is moving!" << endl;
    }
};

int main() {
    Car myCar;
    myCar.start();   // From Engine
    myCar.rotate();  // From Wheels
    myCar.drive();   // From Car

    return 0;
}
