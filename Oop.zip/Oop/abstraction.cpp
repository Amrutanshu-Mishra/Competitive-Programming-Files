#include <iostream>
using namespace std;

// Abstract class (Base class with at least one pure virtual function)
class Shape {
public:
    virtual void draw() = 0;  // Pure virtual function (must be implemented by derived classes)
};

// Derived class 1
class Circle : public Shape {
public:
    void draw() {
        cout << "Drawing a Circle logic....... " << endl;
    }
};

// Derived class 2
class Rectangle : public Shape {
public:
    void draw() {
        cout << "Drawing a Rectangle logic ......" << endl;
    }
};

int main() {
    Shape* s1 = new Circle();
    Shape* s2 = new Rectangle();

    s1->draw();  // Output: Drawing a Circle
    s2->draw();  // Output: Drawing a Rectangle

    delete s1;
    delete s2;

    return 0;
}

// Shape is an abstract class because it has a pure virtual function (draw()).

// Circle and Rectangle override the draw() function and provide implementation.

// The user only calls draw() without worrying about how the shape is drawn internally.