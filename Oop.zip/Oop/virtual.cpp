// #include <iostream>
// using namespace std;

// class Animal {
// public:
//     virtual void makeSound() {  // Virtual function
//         cout << "Animal makes a sound!" << endl;
//     }
// };

// class Dog : public Animal {
// public:
//     void makeSound() {  // Overriding base class function
//         cout << "Dog barks!" << endl;
//     }
// };

// int main() {
//     Animal* a;
//     Dog d;
//     a = &d;

//     a->makeSound();  // Calls Dog's makeSound() because of virtual function

//     return 0;
// }



#include <iostream>
using namespace std;

class SocialWebsite
{
private:
protected:
public:
    virtual void secret() {};
};

class Facebook : public SocialWebsite
{
private:
    string fbPassword;

    void secret()
    {
        cout << "The Facebook password is: " << fbPassword << endl;
        cout << "It's risky, but it's fine to print here as an example." << endl;
    }

public:
    Facebook(string pwd)
    {
        fbPassword = pwd;
    }
};

int main()
{
    Facebook f("Suman95@fb");

    SocialWebsite *s = &f;
    s->secret();
    // f.secret();

    return 0;
}
// //Virtual functions allow runtime polymorphism, meaning that when 
// // a virtual function is called through a base class pointer or reference, 
// // the derived class version of the function is invoked, 
// // even if the derived class version is marked as private.

// //This works because the access control (such as private, protected, or public) 
// // is enforced at compile time. However, once the function is marked as virtual, 
// // the dynamic binding occurs at runtime, where the correct function (even if it's private)
// //  is invoked based on the actual object type.