#include <iostream>
using namespace std;

class BankAccount {
private:
    double balance;  // Private data

public:
  
    BankAccount(double initialBalance) {
        if (initialBalance < 0) {
            balance = 0;
        } else {
            balance = initialBalance;
        }
    }

    // Public method to deposit money
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposited: $" << amount << endl;
        } else {
            cout << "Invalid deposit amount!" << endl;
        }
    }

    // Public method to withdraw money
    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: $" << amount << endl;
        } else {
            cout << "Invalid withdrawal amount!" << endl;
        }
    }

    // Public method to check balance
    double getBalance() {
        return balance;
    }
};

int main() {
    BankAccount myAccount(1000);  // Creating account with $1000

    // myAccount.balance = 5000;  // ❌ ERROR: balance is private


    myAccount.deposit(500);  // Depositing $500
    myAccount.withdraw(300); // Withdrawing $300

    cout << "Current Balance: $" << myAccount.getBalance() << endl; 

    return 0;
}
