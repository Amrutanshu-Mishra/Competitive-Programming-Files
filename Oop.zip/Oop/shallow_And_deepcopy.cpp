#include <iostream>
using namespace std;

class Student {
public:
    int age;
    int* marks;

    // Constructor
    Student(int a, int m) {
        age = a;
        marks = new int(m); // Dynamically allocated memory
    }

    // Default Copy Constructor (Shallow Copy)
    Student(const Student& s) {
        age = s.age;
        marks = s.marks;  // Copies pointer, not memory
    }

    void display() {
        cout << "Age: " << age << ", Marks: " << *marks << endl;
    }
};

int main() {
    Student s1(20, 90);
    Student s2 = s1;  // Shallow Copy (Default Copy Constructor)

    cout << "Before modification:" << endl;
    s1.display();
    s2.display();

    // Changing value in one object affects the other
    *s2.marks = 75;

    cout << "After modifying s2's marks:" << endl;
    s1.display();
    s2.display();  // Both are modified due to shared memory

    return 0;
}



// #include <iostream>
// using namespace std;

// class Student {
// public:
//     int age;
//     int* marks;

//     // Constructor
//     Student(int a, int m) {
//         age = a;
//         marks = new int(m);
//     }

//     // Deep Copy Constructor
//     Student(const Student& s) {
//         age = s.age;
//         marks = new int(*s.marks);  // Allocating new memory
//     }

//     void display() {
//         cout << "Age: " << age << ", Marks: " << *marks << endl;
//     }

//     // Destructor to free memory
//     ~Student() {
//         delete marks;
//     }
// };

// int main() {
//     Student s1(20, 90);
//     Student s2 = s1;  // Deep Copy (Custom Copy Constructor)

//     cout << "Before modification:" << endl;
//     s1.display();
//     s2.display();

//     // Modifying s2's marks
//     *s2.marks = 75;

//     cout << "After modifying s2's marks:" << endl;
//     s1.display();
//     s2.display();  // No effect on s1, because memory is separate

//     return 0;
// }
