#include <iostream>
using namespace std;

class Student {
private:
    int age;

public:
    void setAge(int age) {  
        this->age = age;  // `this` differentiates between member and local variable
    }

    void display() {
        cout << "Age: " << this->age << endl;  
    }
};

int main() {
    Student s1;
    s1.setAge(20);
    s1.display();  // Output: Age: 20
    return 0;
}
