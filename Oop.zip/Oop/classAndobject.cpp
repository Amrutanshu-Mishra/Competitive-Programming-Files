#include <iostream>
#include <string>
using namespace std;
class ClassName {
    // Access Modifiers
    public:
        // Public members (data and methods)
    private:
        // Private members (data and methods)
    protected:
        // Protected members (data and methods)
};

class Car {
    public:
        string brand;  // Public attribute
        string model;  // Public attribute
        int year;      // Public attribute

    private:
        string color;  // Private attribute
        int price;     // Private attribute

    public:
        void display() {
            cout << "Car Brand: " << brand << endl;
            cout << "Car Model: " << model << endl;
            cout << "Car Year: " << year << endl;
        }
};

int main() {
    Car car1;  // Creating an object of class Car

    car1.brand = "Toyota";  // Accessing public attributes
    car1.model = "Corolla";
    car1.year = 2021;

    // car1.color = "Red";  // Cannot access private attributes
    // car1.price = 10000;  // Cannot access private attributes

   car1.display();  // Calling display() method

     cout << car1.brand << " " << car1.model << " " << car1.year << endl;
    return 0;
}



