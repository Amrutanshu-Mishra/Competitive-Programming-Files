// #include <iostream>
// using namespace std;

// class Car {
// public:
//     string brand;

//     // Constructor
//     Car(string b) {  
//         brand = b;
//         cout << brand << " Constructor Called" << endl;
//     }

//     void display() {
//         cout << "Car Brand: " << brand << endl;
//     }

//     // Destructor
//     ~Car() {  
//         cout << brand << " Destructor Called" << endl;
//     }
// };

// int main() {
//     Car car1("Toyota");
//     Car car2("Mercedes");

//     car1.display();
//     car2.display();

//     return 0;  // Destructor is called automatically here
// }


// why we need destructor

#include <iostream>
using namespace std;

class Student {
private:
    int* age;

public:
    // Constructor (Allocating Memory)
    Student(int a) {  
        age = new int(a);
        cout << "Constructor Allocated Memory" << endl;
    }

    // Destructor (Freeing Memory)
    ~Student() {  
        delete age;
        cout << "Destructor Freed Memory" << endl;
    }
};

int main() {
    Student s1(22);  // Constructor is called
    return 0;        // Destructor is automatically called when s1 goes out of scope
}
